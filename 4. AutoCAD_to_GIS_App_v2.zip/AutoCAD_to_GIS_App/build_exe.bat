@echo off
setlocal
cd /d "%~dp0"
echo Checking Python and GDAL...
python -c "from osgeo import gdal, ogr; print(gdal.VersionInfo('--version')); print('GPKG:', bool(ogr.GetDriverByName('GPKG')))"
if errorlevel 1 (
  echo ERROR: Python cannot import GDAL/OGR. Use the Python installation that has GDAL installed.
  pause
  exit /b 1
)
echo Installing or updating PyInstaller...
python -m pip install --upgrade pyinstaller
if errorlevel 1 goto failed
echo Building app bundle...
python -m PyInstaller --noconfirm --clean --windowed --name AutoCADtoGIS --onedir --collect-all osgeo --collect-binaries osgeo --collect-data osgeo autocad_to_gis_app.py
if errorlevel 1 goto failed
echo.
echo Build finished. Check dist\AutoCADtoGIS\AutoCADtoGIS.exe
pause
exit /b 0
:failed
echo.
echo Build failed. Review the error above; GDAL DLL packaging may require environment-specific adjustments.
pause
exit /b 1
