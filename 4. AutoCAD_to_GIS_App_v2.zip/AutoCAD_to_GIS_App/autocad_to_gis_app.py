from __future__ import annotations

import csv
import logging
import shutil
import subprocess
import tempfile
import threading
import traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from osgeo import gdal, ogr

APP_NAME = "AutoCAD to GIS"
DEFAULT_DXF_VERSION = "ACAD2018"

gdal.UseExceptions()
ogr.UseExceptions()
gdal.SetConfigOption("DXF_CLOSED_LINE_AS_POLYGON", "TRUE")
# Avoid GDAL silently truncating dense CAD blocks at the default 10,000 features.
# Set before opening any DXF dataset. Large drawings may take more memory/time.
gdal.SetConfigOption("DXF_FEATURE_LIMIT_PER_BLOCK", "-1")


def find_oda_executable() -> str:
    """Try common Windows install locations; user can browse if not found."""
    candidates = [
        Path(r"C:\Program Files\ODA\ODAFileConverter 27.9.0\ODAFileConverter.exe"),
        Path(r"C:\Program Files\ODA\ODAFileConverter\ODAFileConverter.exe"),
        Path(r"C:\Program Files (x86)\ODA\ODAFileConverter\ODAFileConverter.exe"),
    ]
    for path in candidates:
        if path.is_file():
            return str(path)
    return ""


def safe_name(value: str) -> str:
    invalid = '<>:"/\\|?*'
    result = "".join("_" if ch in invalid or ord(ch) < 32 else ch for ch in value)
    return result.strip(" .") or "cad_file"


def get_field(feature, *names) -> str:
    """Read first available attribute, returning a printable string."""
    for name in names:
        idx = feature.GetFieldIndex(name)
        if idx >= 0 and feature.IsFieldSetAndNotNull(idx):
            try:
                value = feature.GetField(idx)
                return "" if value is None else str(value)
            except Exception:
                pass
    return ""


def geometry_family(geom):
    if geom is None or geom.IsEmpty():
        return None

    if ogr.GT_IsCurve(geom.GetGeometryType()):
        geom = geom.GetLinearGeometry()

    flat = ogr.GT_Flatten(geom.GetGeometryType())

    if flat in (ogr.wkbPoint, ogr.wkbMultiPoint):
        return "point"
    if flat in (ogr.wkbLineString, ogr.wkbMultiLineString, ogr.wkbLinearRing):
        return "line"
    if flat in (ogr.wkbPolygon, ogr.wkbMultiPolygon):
        return "polygon"
    if flat in (ogr.wkbGeometryCollection, ogr.wkbMultiCurve, ogr.wkbMultiSurface):
        return "collection"
    return None


def iter_simple_geometries(geom):
    """Yield point, line and polygon parts; unsupported parts are skipped."""
    if geom is None or geom.IsEmpty():
        return

    if ogr.GT_IsCurve(geom.GetGeometryType()):
        geom = geom.GetLinearGeometry()

    family = geometry_family(geom)
    if family in ("point", "line", "polygon"):
        yield geom
        return

    if family == "collection":
        for index in range(geom.GetGeometryCount()):
            child = geom.GetGeometryRef(index)
            if child is not None:
                yield from iter_simple_geometries(child)


def make_output_layer(dataset, name: str, geometry_type: int):
    layer = dataset.CreateLayer(name, srs=None, geom_type=geometry_type)
    if layer is None:
        raise RuntimeError(f"Could not create output layer {name}")

    # Stable, GIS-friendly schema across different DXF entity types.
    # Shapefile field names are limited to 10 characters.
    fields = [
        ("CAD_LAYER", ogr.OFTString, 120),
        ("ENTITY", ogr.OFTString, 40),
        ("HANDLE", ogr.OFTString, 40),
        ("TEXT", ogr.OFTString, 254),
        ("SOURCE", ogr.OFTString, 120),
    ]
    for field_name, field_type, width in fields:
        definition = ogr.FieldDefn(field_name, field_type)
        definition.SetWidth(width)
        if layer.CreateField(definition) != ogr.OGRERR_NONE:
            raise RuntimeError(f"Could not create field {field_name}")
    return layer


def convert_dxf_to_gis(dxf_path: Path, output_folder: Path, log):
    """Extract DXF entities to per-geometry Shapefiles and one GeoPackage."""
    dataset = ogr.Open(str(dxf_path), 0)
    if dataset is None:
        raise RuntimeError(f"GDAL could not open DXF: {dxf_path}")

    output_folder.mkdir(parents=True, exist_ok=True)
    shp_driver = ogr.GetDriverByName("ESRI Shapefile")
    gpkg_driver = ogr.GetDriverByName("GPKG")
    if shp_driver is None:
        raise RuntimeError("GDAL ESRI Shapefile driver is unavailable.")
    if gpkg_driver is None:
        raise RuntimeError("GDAL GeoPackage driver is unavailable.")

    gpkg_path = output_folder / f"{safe_name(dxf_path.stem)}.gpkg"
    if gpkg_path.exists():
        gpkg_driver.DeleteDataSource(str(gpkg_path))
    gpkg_ds = gpkg_driver.CreateDataSource(str(gpkg_path))
    if gpkg_ds is None:
        raise RuntimeError(f"Could not create {gpkg_path}")

    shp_datasets = {}
    shp_layers = {}
    gpkg_layers = {}
    counts = {"point": 0, "line": 0, "polygon": 0, "skipped": 0}
    family_types = {"point": ogr.wkbUnknown, "line": ogr.wkbUnknown, "polygon": ogr.wkbUnknown}

    try:
        for layer_index in range(dataset.GetLayerCount()):
            source_layer = dataset.GetLayerByIndex(layer_index)
            if source_layer is None:
                continue
            source_layer.ResetReading()
            for feature in source_layer:
                geom = feature.GetGeometryRef()
                if geom is None or geom.IsEmpty():
                    counts["skipped"] += 1
                    continue
                cad_layer = get_field(feature, "Layer") or source_layer.GetName()
                entity = get_field(feature, "SubClasses", "EntityType")
                handle = get_field(feature, "EntityHandle", "Handle")
                text = get_field(feature, "Text", "TextValue")

                for part in iter_simple_geometries(geom):
                    family = geometry_family(part)
                    if family not in family_types:
                        counts["skipped"] += 1
                        continue

                    if family not in gpkg_layers:
                        gpkg_layers[family] = make_output_layer(gpkg_ds, family, family_types[family])
                        shp_path = output_folder / f"{family}.shp"
                        if shp_path.exists():
                            shp_driver.DeleteDataSource(str(shp_path))
                        shp_ds = shp_driver.CreateDataSource(str(shp_path))
                        if shp_ds is None:
                            raise RuntimeError(f"Could not create {shp_path}")
                        shp_datasets[family] = shp_ds
                        shp_layers[family] = make_output_layer(shp_ds, family, family_types[family])

                    for out_layer in (gpkg_layers[family], shp_layers[family]):
                        out_feature = ogr.Feature(out_layer.GetLayerDefn())
                        out_feature.SetField("CAD_LAYER", cad_layer[:120])
                        out_feature.SetField("ENTITY", entity[:40])
                        out_feature.SetField("HANDLE", handle[:40])
                        out_feature.SetField("TEXT", text[:254])
                        out_feature.SetField("SOURCE", dxf_path.stem[:120])
                        out_feature.SetGeometry(part.Clone())
                        try:
                            if out_layer.CreateFeature(out_feature) != ogr.OGRERR_NONE:
                                counts["skipped"] += 1
                            else:
                                # Count once per source entity, not once per output format.
                                if out_layer is gpkg_layers[family]:
                                    counts[family] += 1
                        finally:
                            out_feature = None

        gpkg_ds.FlushCache()
        for out_ds in shp_datasets.values():
            out_ds.FlushCache()
    finally:
        shp_layers.clear()
        shp_datasets.clear()
        gpkg_layers.clear()
        gpkg_ds = None
        dataset = None

    log(f"  Extracted: points={counts['point']}, lines={counts['line']}, polygons={counts['polygon']}, skipped={counts['skipped']}")
    log(f"  GeoPackage: {gpkg_path}")
    return counts


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("820x640")
        self.minsize(680, 500)

        self.input_var = tk.StringVar(value="")
        self.output_var = tk.StringVar(value="")
        self.oda_var = tk.StringVar(value=find_oda_executable())
        self.version_var = tk.StringVar(value=DEFAULT_DXF_VERSION)
        self.audit_var = tk.BooleanVar(value=True)
        self.recursive_var = tk.BooleanVar(value=False)

        self.worker = None
        self._build_ui()

    def _build_ui(self):
        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)
        root.columnconfigure(1, weight=1)
        root.rowconfigure(5, weight=1)

        ttk.Label(root, text="AutoCAD to GIS", font=("Segoe UI", 16, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 10)
        )
        ttk.Label(
            root,
            text="Batch-convert DWG → DXF → SHP + GeoPackage. Local coordinates are preserved; no CRS is guessed or assigned.",
            wraplength=730,
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 12))

        self._path_row(root, 2, "DWG input folder", self.input_var, self._choose_input)
        self._path_row(root, 3, "GIS output folder", self.output_var, self._choose_output)
        self._path_row(root, 4, "ODA executable", self.oda_var, self._choose_oda)

        options = ttk.Frame(root)
        options.grid(row=5, column=0, columnspan=3, sticky="new", pady=(10, 6))
        ttk.Label(options, text="DXF version:").pack(side="left")
        ttk.Combobox(
            options,
            textvariable=self.version_var,
            values=["ACAD2018", "ACAD2013", "ACAD2010", "ACAD2007", "ACAD2004"],
            width=13,
            state="readonly",
        ).pack(side="left", padx=(6, 16))
        ttk.Checkbutton(
            options, text="Audit drawings", variable=self.audit_var
        ).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(
            options, text="Include subfolders", variable=self.recursive_var
        ).pack(side="left")

        self.start_button = ttk.Button(root, text="Start conversion", command=self.start)
        self.start_button.grid(row=6, column=0, sticky="w", pady=8)

        self.progress = ttk.Progressbar(root, mode="indeterminate")
        self.progress.grid(row=6, column=1, sticky="ew", padx=10, pady=8)

        ttk.Label(root, text="Processing log").grid(
            row=7, column=0, columnspan=3, sticky="w"
        )
        self.log_box = tk.Text(root, height=13, wrap="word", state="disabled")
        self.log_box.grid(row=8, column=0, columnspan=3, sticky="nsew", pady=(5, 0))
        root.rowconfigure(8, weight=1)

        self.log(f"GDAL {gdal.VersionInfo('--version')}")
        self.log("DXF driver: " + ("available" if ogr.GetDriverByName("DXF") else "MISSING"))
        self.log(
            "Shapefile driver: "
            + ("available" if ogr.GetDriverByName("ESRI Shapefile") else "MISSING")
        )

    def _path_row(self, parent, row, label, variable, callback):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=variable).grid(
            row=row, column=1, sticky="ew", padx=8, pady=4
        )
        ttk.Button(parent, text="Browse…", command=callback).grid(
            row=row, column=2, sticky="e", pady=4
        )

    def _choose_input(self):
        path = filedialog.askdirectory(title="Select folder containing DWG files")
        if path:
            self.input_var.set(path)
            if not self.output_var.get():
                self.output_var.set(str(Path(path).parent / "GIS_Output"))

    def _choose_output(self):
        path = filedialog.askdirectory(title="Select GIS output folder")
        if path:
            self.output_var.set(path)

    def _choose_oda(self):
        path = filedialog.askopenfilename(
            title="Select ODAFileConverter.exe",
            filetypes=[("ODA File Converter", "ODAFileConverter.exe"), ("Executables", "*.exe")],
        )
        if path:
            self.oda_var.set(path)

    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_box.configure(state="normal")
        self.log_box.insert("end", f"[{timestamp}] {message}\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def log_from_worker(self, message):
        self.after(0, lambda: self.log(message))

    def start(self):
        input_dir = Path(self.input_var.get().strip())
        output_dir = Path(self.output_var.get().strip())
        oda_exe = Path(self.oda_var.get().strip())

        if not input_dir.is_dir():
            messagebox.showerror("Input required", "Select an existing DWG input folder.")
            return
        if not oda_exe.is_file():
            messagebox.showerror("ODA required", "Select the installed ODAFileConverter.exe.")
            return
        if not output_dir:
            messagebox.showerror("Output required", "Select an output folder.")
            return
        if not ogr.GetDriverByName("DXF") or not ogr.GetDriverByName("ESRI Shapefile") or not ogr.GetDriverByName("GPKG"):
            messagebox.showerror("GDAL driver missing", "GDAL DXF, ESRI Shapefile and GeoPackage drivers are required.")
            return

        pattern = "**/*.dwg" if self.recursive_var.get() else "*.dwg"
        files = list(input_dir.glob(pattern))
        pattern_upper = "**/*.DWG" if self.recursive_var.get() else "*.DWG"
        files += [p for p in input_dir.glob(pattern_upper) if p not in files]

        if not files:
            messagebox.showinfo("No DWG files", "No .dwg files were found in the selected folder.")
            return

        self.start_button.configure(state="disabled")
        self.progress.start(10)
        self.log(f"Found {len(files)} DWG file(s). Starting batch conversion.")
        self.worker = threading.Thread(
            target=self._run_batch,
            args=(files, input_dir, output_dir, oda_exe),
            daemon=True,
        )
        self.worker.start()

    def _run_batch(self, files, input_dir, output_dir, oda_exe):
        summary_rows = []
        success = 0
        failed = 0

        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            for number, dwg_path in enumerate(files, start=1):
                self.log_from_worker(f"[{number}/{len(files)}] {dwg_path.name}")
                file_output = output_dir / safe_name(dwg_path.stem)
                file_output.mkdir(parents=True, exist_ok=True)

                try:
                    with tempfile.TemporaryDirectory(prefix="cad2gis_") as temp_name:
                        temp_root = Path(temp_name)
                        temp_in = temp_root / "input"
                        temp_dxf = temp_root / "dxf"
                        temp_in.mkdir()
                        temp_dxf.mkdir()

                        # Isolate each source file to prevent duplicate-name collisions.
                        staged_dwg = temp_in / dwg_path.name
                        shutil.copy2(dwg_path, staged_dwg)

                        command = [
                            str(oda_exe),
                            str(temp_in),
                            str(temp_dxf),
                            self.version_var.get(),
                            "DXF",
                            "0",  # process this folder only
                            "1" if self.audit_var.get() else "0",
                            "*.dwg",
                        ]
                        result = subprocess.run(
                            command,
                            capture_output=True,
                            text=True,
                            timeout=600,
                            check=False,
                        )
                        dxf_files = list(temp_dxf.glob("*.dxf")) + list(temp_dxf.glob("*.DXF"))
                        if result.returncode != 0 or not dxf_files:
                            detail = (result.stderr or result.stdout or "").strip()
                            raise RuntimeError(
                                f"ODA conversion failed (return code {result.returncode}). {detail}"
                            )

                        dxf_path = dxf_files[0]
                        self.log_from_worker(f"  DXF created; extracting GIS geometries…")
                        counts = convert_dxf_to_gis(
                            dxf_path, file_output, self.log_from_worker
                        )

                    success += 1
                    summary_rows.append({
                        "source_file": str(dwg_path),
                        "status": "success",
                        "points": counts["point"],
                        "lines": counts["line"],
                        "polygons": counts["polygon"],
                        "skipped": counts["skipped"],
                        "message": "",
                    })
                    self.log_from_worker(f"  DONE → {file_output}")

                except Exception as exc:
                    failed += 1
                    message = str(exc)
                    self.log_from_worker(f"  ERROR: {message}")
                    summary_rows.append({
                        "source_file": str(dwg_path),
                        "status": "failed",
                        "points": 0,
                        "lines": 0,
                        "polygons": 0,
                        "skipped": 0,
                        "message": message,
                    })

            report_path = output_dir / "conversion_report.csv"
            with report_path.open("w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "source_file", "status", "points", "lines",
                        "polygons", "skipped", "message",
                    ],
                )
                writer.writeheader()
                writer.writerows(summary_rows)

            self.log_from_worker(
                f"Finished. Successful files: {success}; failed files: {failed}."
            )
            self.log_from_worker(f"Report: {report_path}")
            self.after(
                0,
                lambda: messagebox.showinfo(
                    "Conversion finished",
                    f"Successful: {success}\nFailed: {failed}\n\nReport:\n{report_path}",
                ),
            )
        except Exception:
            detail = traceback.format_exc()
            self.log_from_worker(detail)
        finally:
            self.after(0, self._finish)

    def _finish(self):
        self.progress.stop()
        self.start_button.configure(state="normal")


if __name__ == "__main__":
    App().mainloop()
